
import { GoogleGenAI, Type } from "@google/genai";
import { PlantDiagnosis, ChatMessage } from "../types";
import { SYSTEM_INSTRUCTION, DIAGNOSIS_PROMPT } from "../constants";

// Initializing GoogleGenAI with the API key from environment variables directly.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const diagnosePlant = async (base64Image: string): Promise<PlantDiagnosis> => {
  try {
    // Using gemini-3-pro-preview for complex plant diagnosis reasoning from an image.
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: {
        parts: [
          { inlineData: { data: base64Image, mimeType: "image/jpeg" } },
          { text: DIAGNOSIS_PROMPT }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            plantName: { type: Type.STRING },
            healthStatus: { type: Type.STRING },
            issue: { type: Type.STRING },
            description: { type: Type.STRING },
            treatmentPlan: { type: Type.ARRAY, items: { type: Type.STRING } },
            careReminders: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["plantName", "healthStatus", "issue", "description", "treatmentPlan", "careReminders"]
        }
      }
    });

    // Accessing .text property directly to get the generated response string.
    const resultText = response.text || "";
    return JSON.parse(resultText) as PlantDiagnosis;
  } catch (error) {
    console.error("Diagnosis error:", error);
    throw new Error("Failed to analyze the plant. Please try again with a clearer photo.");
  }
};

export const startPlantChat = (history: ChatMessage[]) => {
  const chatHistory = history.map(msg => ({
    role: msg.role,
    parts: [{ text: msg.text }]
  }));

  // Using gemini-3-flash-preview for general chat tasks and passing history to maintain context.
  return ai.chats.create({
    model: "gemini-3-flash-preview",
    // @ts-ignore - Providing history to maintain conversation state.
    history: chatHistory,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
    }
  });
};
