
import React, { useState, useEffect } from 'react';
import { Tab, MyPlant, PlantDiagnosis, AuthMode, CareTask } from './types';
import { Layout } from './components/Layout';
import { PlantCard } from './components/PlantCard';
import { ChatInterface } from './components/ChatInterface';
import { diagnosePlant } from './services/plantService';
import { 
  Sprout, 
  Search, 
  Plus, 
  ArrowLeft, 
  Droplets, 
  Sun, 
  Wind, 
  ShieldAlert, 
  CheckCircle2, 
  Loader2,
  AlertCircle,
  MessageCircle,
  Camera,
  LogOut,
  Settings,
  Bell,
  Leaf,
  Calendar as CalendarIcon,
  ChevronRight,
  User as UserIcon,
  Lock,
  Mail
} from 'lucide-react';

const App: React.FC = () => {
  const [authMode, setAuthMode] = useState<AuthMode>('Login');
  const [activeTab, setActiveTab] = useState<Tab>(Tab.Home);
  const [myPlants, setMyPlants] = useState<MyPlant[]>([]);
  const [tasks, setTasks] = useState<CareTask[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<PlantDiagnosis | null>(null);
  const [selectedPlant, setSelectedPlant] = useState<MyPlant | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Authentication Mock Logic
  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthMode('Authenticated');
  };

  useEffect(() => {
    if (authMode !== 'Authenticated') return;

    const savedPlants = localStorage.getItem('healplant_collection');
    if (savedPlants) {
      setMyPlants(JSON.parse(savedPlants));
    } else {
      const initial: MyPlant[] = [
        { id: '1', name: 'Monstera Mayo', species: 'Monstera Deliciosa', status: 'Healthy', image: 'https://images.unsplash.com/photo-1614594975525-e45190c55d0b?w=400&h=400&fit=crop', addedAt: Date.now() },
        { id: '2', name: 'Kitchen Aloe', species: 'Aloe Vera', status: 'Needs Attention', image: 'https://images.unsplash.com/photo-1596547609652-9cf5d8d76921?w=400&h=400&fit=crop', addedAt: Date.now() - 86400000 },
      ];
      setMyPlants(initial);
      localStorage.setItem('healplant_collection', JSON.stringify(initial));
    }

    const savedTasks = localStorage.getItem('healplant_tasks');
    if (savedTasks) {
      setTasks(JSON.parse(savedTasks));
    } else {
      const initialTasks: CareTask[] = [
        { id: 't1', plantId: '1', plantName: 'Monstera Mayo', type: 'Water', dueDate: new Date().toISOString().split('T')[0], completed: false },
        { id: 't2', plantId: '2', plantName: 'Kitchen Aloe', type: 'Fertilize', dueDate: new Date().toISOString().split('T')[0], completed: false },
        { id: 't3', plantId: '1', plantName: 'Monstera Mayo', type: 'Prune', dueDate: new Date(Date.now() + 86400000).toISOString().split('T')[0], completed: false },
      ];
      setTasks(initialTasks);
      localStorage.setItem('healplant_tasks', JSON.stringify(initialTasks));
    }
  }, [authMode]);

  const toggleTask = (taskId: string) => {
    const updated = tasks.map(t => t.id === taskId ? { ...t, completed: !t.completed } : t);
    setTasks(updated);
    localStorage.setItem('healplant_tasks', JSON.stringify(updated));
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError(null);
    setLoading(true);
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = (reader.result as string).split(',')[1];
      try {
        const result = await diagnosePlant(base64);
        setScanResult(result);
        setIsScanning(true);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const saveToCollection = () => {
    if (!scanResult) return;
    const newPlant: MyPlant = {
      id: Date.now().toString(),
      name: scanResult.plantName,
      species: scanResult.plantName,
      status: scanResult.healthStatus,
      image: 'https://images.unsplash.com/photo-1545239351-ef35f43d514b?w=400&h=400&fit=crop',
      addedAt: Date.now(),
      lastDiagnosis: scanResult.issue
    };
    const updated = [newPlant, ...myPlants];
    setMyPlants(updated);
    localStorage.setItem('healplant_collection', JSON.stringify(updated));
    
    // Add initial task for the new plant
    const newTask: CareTask = {
      id: 't_' + Date.now(),
      plantId: newPlant.id,
      plantName: newPlant.name,
      type: 'Water',
      dueDate: new Date().toISOString().split('T')[0],
      completed: false
    };
    const updatedTasks = [newTask, ...tasks];
    setTasks(updatedTasks);
    localStorage.setItem('healplant_tasks', JSON.stringify(updatedTasks));

    setScanResult(null);
    setIsScanning(false);
    setActiveTab(Tab.MyPlants);
  };

  if (authMode !== 'Authenticated') {
    return (
      <div className="flex flex-col min-h-screen bg-white max-w-md mx-auto p-8 justify-center items-center">
        <div className="w-20 h-20 leaf-gradient rounded-3xl flex items-center justify-center text-white mb-8 shadow-2xl shadow-emerald-200">
          <Sprout size={40} strokeWidth={2.5} />
        </div>
        <h1 className="text-3xl font-black text-slate-800 mb-2">HealPlant.AI</h1>
        <p className="text-slate-400 text-center mb-10 px-4">The smartest way to care for your green companions.</p>
        
        <form onSubmit={handleAuth} className="w-full space-y-4">
          {authMode === 'Register' && (
            <div className="relative">
              <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input type="text" placeholder="Full Name" className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-emerald-500/10 transition-all" required />
            </div>
          )}
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input type="email" placeholder="Email Address" className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-emerald-500/10 transition-all" required />
          </div>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input type="password" placeholder="Password" className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-emerald-500/10 transition-all" required />
          </div>
          
          <button type="submit" className="w-full leaf-gradient py-4 rounded-2xl text-white font-bold shadow-xl shadow-emerald-200 active:scale-95 transition-all">
            {authMode === 'Login' ? 'Sign In' : 'Create Account'}
          </button>
        </form>

        <p className="mt-8 text-sm text-slate-500">
          {authMode === 'Login' ? "Don't have an account?" : "Already have an account?"}
          <button onClick={() => setAuthMode(authMode === 'Login' ? 'Register' : 'Login')} className="ml-2 text-emerald-600 font-bold hover:underline">
            {authMode === 'Login' ? 'Sign Up' : 'Log In'}
          </button>
        </p>
      </div>
    );
  }

  const renderHome = () => (
    <div className="p-6">
      <header className="mb-8 flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-black text-emerald-950">Hello, Gardener!</h1>
          <p className="text-sm text-emerald-600/60 font-medium">Your plants are doing great today.</p>
        </div>
        <div className="flex gap-2">
          <button className="w-10 h-10 rounded-full bg-white border border-slate-100 flex items-center justify-center text-slate-600 relative">
            <Bell size={20} />
            <span className="absolute top-2 right-2 w-2 h-2 bg-rose-500 rounded-full border-2 border-white"></span>
          </button>
        </div>
      </header>

      <div className="bg-emerald-600 rounded-[32px] p-6 text-white mb-8 relative overflow-hidden shadow-xl shadow-emerald-100">
        <div className="relative z-10">
          <h3 className="text-lg font-bold mb-1">Health Summary</h3>
          <div className="flex gap-4 mt-4">
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 flex-1">
              <p className="text-[10px] font-bold uppercase opacity-60">Healthy</p>
              <p className="text-xl font-black">{myPlants.filter(p => p.status === 'Healthy').length}</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 flex-1">
              <p className="text-[10px] font-bold uppercase opacity-60">Issues</p>
              <p className="text-xl font-black">{myPlants.filter(p => p.status !== 'Healthy').length}</p>
            </div>
          </div>
        </div>
        <Leaf className="absolute -right-6 -bottom-6 text-white/10" size={120} />
      </div>

      <section className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-bold text-slate-800">Tasks for Today</h2>
          <button onClick={() => setActiveTab(Tab.Calendar)} className="text-emerald-600 text-xs font-bold">View Calendar</button>
        </div>
        <div className="space-y-3">
          {tasks.filter(t => t.dueDate === new Date().toISOString().split('T')[0]).slice(0, 3).map(task => (
            <div key={task.id} className="bg-white p-4 rounded-3xl border border-slate-100 flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => toggleTask(task.id)}
                  className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${task.completed ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-slate-200'}`}
                >
                  {task.completed && <CheckCircle2 size={14} />}
                </button>
                <div>
                  <p className={`text-sm font-bold ${task.completed ? 'text-slate-400 line-through' : 'text-slate-800'}`}>{task.type} {task.plantName}</p>
                  <p className="text-[10px] text-slate-400">Due today</p>
                </div>
              </div>
              <ChevronRight className="text-slate-300" size={18} />
            </div>
          ))}
          {tasks.filter(t => t.dueDate === new Date().toISOString().split('T')[0]).length === 0 && (
            <p className="text-slate-400 text-sm text-center py-4 italic">No tasks for today! Take a rest.</p>
          )}
        </div>
      </section>

      <section>
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-bold text-slate-800">My Jungle</h2>
          <button onClick={() => setActiveTab(Tab.MyPlants)} className="text-emerald-600 text-xs font-bold">View All</button>
        </div>
        {myPlants.slice(0, 2).map(plant => (
          <PlantCard key={plant.id} plant={plant} onClick={() => {
            setSelectedPlant(plant);
            setActiveTab(Tab.MyPlants);
          }} />
        ))}
      </section>
    </div>
  );

  const renderCalendar = () => (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-slate-800 mb-6">Care Calendar</h1>
      <div className="flex gap-2 overflow-x-auto pb-4 no-scrollbar mb-6">
        {[0, 1, 2, 3, 4, 5, 6].map(i => {
          const d = new Date();
          d.setDate(d.getDate() + i);
          const isToday = i === 0;
          return (
            <div key={i} className={`flex flex-col items-center min-w-[60px] p-3 rounded-2xl border ${isToday ? 'bg-emerald-600 border-emerald-600 text-white shadow-lg' : 'bg-white border-slate-100 text-slate-800'}`}>
              <span className="text-[10px] font-bold uppercase opacity-60">{d.toLocaleDateString('en-US', { weekday: 'short' })}</span>
              <span className="text-lg font-black">{d.getDate()}</span>
            </div>
          );
        })}
      </div>

      <div className="space-y-4">
        {tasks.sort((a,b) => a.dueDate.localeCompare(b.dueDate)).map(task => (
          <div key={task.id} className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-4">
             <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
               task.type === 'Water' ? 'bg-sky-50 text-sky-500' : 
               task.type === 'Fertilize' ? 'bg-amber-50 text-amber-500' : 'bg-purple-50 text-purple-500'
             }`}>
               {task.type === 'Water' ? <Droplets size={24} /> : task.type === 'Fertilize' ? <Sprout size={24} /> : <Wind size={24} />}
             </div>
             <div className="flex-1">
               <h4 className="font-bold text-slate-800 text-sm">{task.type}: {task.plantName}</h4>
               <p className="text-[10px] text-slate-400 font-medium">Scheduled for {task.dueDate}</p>
             </div>
             <button 
              onClick={() => toggleTask(task.id)}
              className={`px-4 py-2 rounded-xl text-[10px] font-bold transition-all ${task.completed ? 'bg-slate-100 text-slate-400' : 'bg-emerald-100 text-emerald-700'}`}
             >
               {task.completed ? 'DONE' : 'MARK'}
             </button>
          </div>
        ))}
      </div>
    </div>
  );

  const renderProfile = () => (
    <div className="p-6">
      <div className="flex flex-col items-center py-8">
        <div className="w-24 h-24 rounded-full border-4 border-emerald-100 p-1 mb-4">
          <div className="w-full h-full rounded-full bg-emerald-600 flex items-center justify-center text-white text-2xl font-black">
            JD
          </div>
        </div>
        <h2 className="text-xl font-bold text-slate-800">Jane Doe</h2>
        <p className="text-sm text-slate-400">Green Thumb Enthusiast</p>
      </div>

      <div className="space-y-3 mt-6">
        <button className="w-full flex items-center justify-between p-4 bg-white rounded-3xl border border-slate-100 shadow-sm active:bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-600">
              <UserIcon size={20} />
            </div>
            <span className="text-sm font-bold text-slate-700">Account Settings</span>
          </div>
          <ChevronRight size={18} className="text-slate-300" />
        </button>
        <button className="w-full flex items-center justify-between p-4 bg-white rounded-3xl border border-slate-100 shadow-sm active:bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-600">
              <Bell size={20} />
            </div>
            <span className="text-sm font-bold text-slate-700">Notifications</span>
          </div>
          <ChevronRight size={18} className="text-slate-300" />
        </button>
        <button className="w-full flex items-center justify-between p-4 bg-white rounded-3xl border border-slate-100 shadow-sm active:bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-600">
              <Settings size={20} />
            </div>
            <span className="text-sm font-bold text-slate-700">App Preferences</span>
          </div>
          <ChevronRight size={18} className="text-slate-300" />
        </button>
        <button 
          onClick={() => setAuthMode('Login')}
          className="w-full flex items-center justify-between p-4 bg-rose-50 rounded-3xl border border-rose-100 shadow-sm active:bg-rose-100 mt-6"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-100 flex items-center justify-center text-rose-600">
              <LogOut size={20} />
            </div>
            <span className="text-sm font-bold text-rose-700">Log Out</span>
          </div>
        </button>
      </div>

      <p className="text-center text-[10px] text-slate-300 mt-12 font-bold uppercase tracking-widest">HealPlant.AI v2.0.1</p>
    </div>
  );

  const renderScan = () => (
    <div className="p-6 min-h-full">
      {!isScanning ? (
        <div className="flex flex-col items-center justify-center py-10">
          <h1 className="text-2xl font-bold text-slate-800 mb-8 text-center">Scan Your Plant</h1>
          <div className="w-full max-w-sm aspect-[4/5] bg-emerald-50 rounded-[40px] border-4 border-dashed border-emerald-200 flex flex-col items-center justify-center gap-6 relative overflow-hidden group shadow-inner">
            <div className="w-20 h-20 bg-white rounded-3xl shadow-xl flex items-center justify-center text-emerald-500 group-hover:scale-110 transition-transform">
              {loading ? <Loader2 className="animate-spin" size={40} /> : <Camera size={40} />}
            </div>
            <div className="text-center px-8">
              <p className="font-black text-emerald-900 text-lg">Snap a Photo</p>
              <p className="text-sm text-emerald-700/60 mt-2">Position the affected area clearly in the center of the frame.</p>
            </div>
            <input 
              type="file" 
              accept="image/*" 
              capture="environment"
              onChange={handleFileUpload}
              className="absolute inset-0 opacity-0 cursor-pointer"
              disabled={loading}
            />
          </div>

          {error && (
            <div className="mt-6 p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-start gap-3 text-rose-700 animate-fade-in-up">
              <AlertCircle size={20} className="shrink-0" />
              <p className="text-xs font-medium">{error}</p>
            </div>
          )}

          <div className="mt-12 w-full">
            <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm">
              <h3 className="font-bold text-slate-800 mb-4">Diagnosis Checklist</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600"><Sun size={16} /></div>
                  <p className="text-xs font-medium text-slate-500">Ensure bright natural lighting</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600"><ShieldAlert size={16} /></div>
                  <p className="text-xs font-medium text-slate-500">Focus on spots or pests</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="animate-fade-in-up">
          <div className="flex justify-between items-center mb-6">
            <button onClick={() => setIsScanning(false)} className="w-10 h-10 rounded-full bg-white border border-slate-100 flex items-center justify-center text-slate-400">
              <ArrowLeft size={20} />
            </button>
            <h1 className="font-bold text-slate-800">AI Diagnosis</h1>
            <div className="w-10" />
          </div>

          {scanResult && (
            <div className="space-y-6">
              <div className="bg-white rounded-[32px] p-6 border border-slate-100 shadow-xl shadow-emerald-50">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h2 className="text-2xl font-black text-emerald-950">{scanResult.plantName}</h2>
                    <p className="text-sm font-bold text-rose-500">{scanResult.issue}</p>
                  </div>
                  <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                    scanResult.healthStatus === 'Healthy' ? 'bg-emerald-100 text-emerald-700' : 
                    scanResult.healthStatus === 'Needs Attention' ? 'bg-amber-100 text-amber-700' : 'bg-rose-100 text-rose-700'
                  }`}>
                    {scanResult.healthStatus}
                  </div>
                </div>
                <p className="text-sm text-slate-600 leading-relaxed mb-4 font-medium">
                  {scanResult.description}
                </p>
              </div>

              <div className="space-y-4">
                <h3 className="font-bold text-slate-800 flex items-center gap-2 px-2">
                  <ShieldAlert size={18} className="text-emerald-600" />
                  Treatment Steps
                </h3>
                <div className="space-y-3">
                  {scanResult.treatmentPlan.map((step, idx) => (
                    <div key={idx} className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm flex gap-4 items-center">
                      <div className="w-8 h-8 rounded-2xl bg-emerald-600 text-white text-xs font-black flex items-center justify-center shrink-0 shadow-lg shadow-emerald-100">
                        {idx + 1}
                      </div>
                      <p className="text-xs font-bold text-slate-700 leading-tight">{step}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="font-bold text-slate-800 flex items-center gap-2 px-2">
                  <CheckCircle2 size={18} className="text-emerald-600" />
                  Long-term Care
                </h3>
                <div className="flex flex-wrap gap-2 px-2">
                  {scanResult.careReminders.map((reminder, idx) => (
                    <span key={idx} className="bg-emerald-50 text-emerald-700 px-4 py-2 rounded-2xl text-[10px] font-bold border border-emerald-100 flex items-center gap-2">
                      <CheckCircle2 size={12} />
                      {reminder}
                    </span>
                  ))}
                </div>
              </div>

              <button 
                onClick={saveToCollection}
                className="w-full leaf-gradient py-5 rounded-3xl text-white font-black shadow-xl shadow-emerald-200 active:scale-95 transition-all mt-4 mb-8"
              >
                Save & Add Tasks
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );

  const renderMyPlants = () => {
    if (selectedPlant) {
      return (
        <div className="p-6">
          <button onClick={() => setSelectedPlant(null)} className="mb-6 flex items-center gap-2 text-slate-500 text-sm font-bold hover:text-emerald-600 transition-colors">
            <ArrowLeft size={18} />
            Collection
          </button>
          <div className="w-full aspect-square rounded-[40px] overflow-hidden mb-6 shadow-2xl ring-8 ring-white">
            <img src={selectedPlant.image} alt={selectedPlant.name} className="w-full h-full object-cover" />
          </div>
          <div className="flex justify-between items-start mb-6 px-2">
            <div>
              <h1 className="text-3xl font-black text-slate-800">{selectedPlant.name}</h1>
              <p className="text-emerald-600 italic font-bold text-sm">{selectedPlant.species}</p>
            </div>
            <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
              selectedPlant.status === 'Healthy' ? 'bg-emerald-100 text-emerald-700' : 
              selectedPlant.status === 'Needs Attention' ? 'bg-amber-100 text-amber-700' : 'bg-rose-100 text-rose-700'
            }`}>
              {selectedPlant.status}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 mb-8">
            <div className="bg-white p-4 rounded-3xl border border-slate-50 text-center shadow-sm">
              <Droplets className="mx-auto text-sky-500 mb-2" size={24} />
              <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest">Water</p>
              <p className="text-xs font-black text-slate-800">7 Days</p>
            </div>
            <div className="bg-white p-4 rounded-3xl border border-slate-50 text-center shadow-sm">
              <Sun className="mx-auto text-amber-500 mb-2" size={24} />
              <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest">Light</p>
              <p className="text-xs font-black text-slate-800">Partial</p>
            </div>
            <div className="bg-white p-4 rounded-3xl border border-slate-50 text-center shadow-sm">
              <Wind className="mx-auto text-emerald-500 mb-2" size={24} />
              <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest">Humidity</p>
              <p className="text-xs font-black text-slate-800">High</p>
            </div>
          </div>

          <div className="space-y-4 px-2">
            <h3 className="font-bold text-slate-800">Health History</h3>
            <div className="bg-emerald-50 p-6 rounded-[32px] border border-emerald-100">
              <p className="text-sm text-emerald-900 leading-relaxed font-medium">
                {selectedPlant.lastDiagnosis || "Everything looks perfect! Continue with the current care routine."}
              </p>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-black text-slate-800">My Jungle</h1>
          <button onClick={() => setActiveTab(Tab.Scan)} className="w-10 h-10 rounded-full leaf-gradient text-white flex items-center justify-center shadow-lg shadow-emerald-200">
            <Plus size={24} />
          </button>
        </div>
        {myPlants.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-24 h-24 bg-emerald-50 rounded-[40px] flex items-center justify-center mx-auto mb-6 text-emerald-200">
              <Sprout size={48} />
            </div>
            <p className="text-slate-500 font-bold text-lg mb-2">No plants yet</p>
            <p className="text-slate-400 text-sm mb-8 px-12 leading-relaxed">Scan your first plant to start your personal AI garden collection.</p>
            <button onClick={() => setActiveTab(Tab.Scan)} className="leaf-gradient px-8 py-4 rounded-2xl text-white font-bold shadow-xl shadow-emerald-100 active:scale-95 transition-all">
              Start Scanning
            </button>
          </div>
        ) : (
          <div className="space-y-1">
            {myPlants.map(plant => (
              <PlantCard key={plant.id} plant={plant} onClick={() => setSelectedPlant(plant)} />
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab}>
      {activeTab === Tab.Home && renderHome()}
      {activeTab === Tab.Calendar && renderCalendar()}
      {activeTab === Tab.Scan && renderScan()}
      {activeTab === Tab.Chat && (
        <div className="h-full flex flex-col">
          <div className="p-6 pb-2">
            <h1 className="text-2xl font-black text-slate-800">HealAI Assistant</h1>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">AI Expert Support</p>
          </div>
          <ChatInterface />
        </div>
      )}
      {activeTab === Tab.Profile && renderProfile()}
      {activeTab === Tab.MyPlants && renderMyPlants()}
    </Layout>
  );
};

export default App;
