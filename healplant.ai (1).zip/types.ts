
export interface PlantDiagnosis {
  plantName: string;
  healthStatus: 'Healthy' | 'Needs Attention' | 'Critical';
  issue: string;
  description: string;
  treatmentPlan: string[];
  careReminders: string[];
}

export interface MyPlant {
  id: string;
  name: string;
  species: string;
  status: 'Healthy' | 'Needs Attention' | 'Critical';
  image: string;
  lastDiagnosis?: string;
  addedAt: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export interface CareTask {
  id: string;
  plantId: string;
  plantName: string;
  type: 'Water' | 'Fertilize' | 'Prune' | 'Repot';
  dueDate: string;
  completed: boolean;
}

export enum Tab {
  Home = 'Home',
  Calendar = 'Calendar',
  Scan = 'Scan',
  Chat = 'Chat',
  Profile = 'Profile',
  MyPlants = 'MyPlants'
}

export type AuthMode = 'Login' | 'Register' | 'Authenticated';
