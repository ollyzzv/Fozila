
import React from 'react';
import { Tab } from '../types';
import { Home, Camera, MessageCircle, Sprout, Calendar, User } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab }) => {
  return (
    <div className="flex flex-col min-h-screen bg-slate-50 max-w-md mx-auto relative overflow-x-hidden border-x border-slate-200 shadow-xl">
      <main className="flex-1 pb-24 overflow-y-auto">
        {children}
      </main>

      <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full bg-white/90 backdrop-blur-xl border-t border-slate-100 px-4 py-3 flex justify-between items-center max-w-md z-50 safe-bottom">
        <button 
          onClick={() => setActiveTab(Tab.Home)}
          className={`flex flex-col items-center gap-1 transition-all ${activeTab === Tab.Home ? 'text-emerald-600 scale-110' : 'text-slate-400'}`}
        >
          <Home size={22} strokeWidth={activeTab === Tab.Home ? 2.5 : 2} />
          <span className="text-[9px] font-bold">Home</span>
        </button>
        
        <button 
          onClick={() => setActiveTab(Tab.Calendar)}
          className={`flex flex-col items-center gap-1 transition-all ${activeTab === Tab.Calendar ? 'text-emerald-600 scale-110' : 'text-slate-400'}`}
        >
          <Calendar size={22} strokeWidth={activeTab === Tab.Calendar ? 2.5 : 2} />
          <span className="text-[9px] font-bold">Calendar</span>
        </button>

        <div className="relative -top-6">
          <button 
            onClick={() => setActiveTab(Tab.Scan)}
            className={`w-14 h-14 rounded-full leaf-gradient flex items-center justify-center text-white shadow-xl shadow-emerald-200 active:scale-90 transition-transform ${activeTab === Tab.Scan ? 'ring-4 ring-emerald-100' : ''}`}
          >
            <Camera size={26} />
          </button>
        </div>

        <button 
          onClick={() => setActiveTab(Tab.Chat)}
          className={`flex flex-col items-center gap-1 transition-all ${activeTab === Tab.Chat ? 'text-emerald-600 scale-110' : 'text-slate-400'}`}
        >
          <MessageCircle size={22} strokeWidth={activeTab === Tab.Chat ? 2.5 : 2} />
          <span className="text-[9px] font-bold">HealAI</span>
        </button>

        <button 
          onClick={() => setActiveTab(Tab.Profile)}
          className={`flex flex-col items-center gap-1 transition-all ${activeTab === Tab.Profile ? 'text-emerald-600 scale-110' : 'text-slate-400'}`}
        >
          <User size={22} strokeWidth={activeTab === Tab.Profile ? 2.5 : 2} />
          <span className="text-[9px] font-bold">Profile</span>
        </button>
      </nav>
    </div>
  );
};
