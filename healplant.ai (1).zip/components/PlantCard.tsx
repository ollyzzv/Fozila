
import React from 'react';
import { MyPlant } from '../types';
import { HeartPulse, ChevronRight } from 'lucide-react';

interface PlantCardProps {
  plant: MyPlant;
  onClick: () => void;
}

export const PlantCard: React.FC<PlantCardProps> = ({ plant, onClick }) => {
  const getStatusColor = () => {
    switch (plant.status) {
      case 'Healthy': return 'bg-emerald-100 text-emerald-700';
      case 'Needs Attention': return 'bg-amber-100 text-amber-700';
      case 'Critical': return 'bg-rose-100 text-rose-700';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  return (
    <div 
      onClick={onClick}
      className="bg-white rounded-3xl p-4 flex items-center gap-4 border border-slate-100 shadow-sm active:bg-slate-50 transition-colors cursor-pointer mb-3"
    >
      <div className="w-16 h-16 rounded-2xl overflow-hidden bg-emerald-50 shrink-0">
        <img src={plant.image} alt={plant.name} className="w-full h-full object-cover" />
      </div>
      <div className="flex-1">
        <h3 className="font-bold text-slate-800 text-sm leading-tight">{plant.name}</h3>
        <p className="text-xs text-slate-400 italic mb-1">{plant.species}</p>
        <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${getStatusColor()}`}>
          <HeartPulse size={10} />
          {plant.status}
        </div>
      </div>
      <ChevronRight className="text-slate-300" size={20} />
    </div>
  );
};
